#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <testBoard.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>

#ifdef __cplusplus
extern "C" {
#endif

/**/



#define D1_PORT PIOB
#define D1_PIN 27
#define D2_PORT PIOD
#define D2_PIN 8
#define D3_PORT PIOD
#define D3_PIN 7
#define D4_PORT PIOA
#define D4_PIN 28



uint32_t ticks_interval=0;
uint32_t fticks = 84000000/32; //TC0_CLK / lolko pocasnej od sistem clocka hocemo da je
//dc v % duty cycle
//f v hz
//število ugasnjenih ciklov
//število prižganih ciklov
uint32_t dc = 25, freq = 1, dcHigh=0, dcLow=0, rc_state=0;
uint32_t state=0;

uint32_t stanje_LED=0;
uint32_t stanje_LED2=0;
uint32_t stevec=0;
uint32_t interval =0;
int fronte=0;

uint32_t blink1 =0;
uint32_t blink2 =0;

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;



    /********************* HW init     ***************************/




    delay_init();
    init_buttons_leds();
    lcd_init();



    uint8_t n=sprintf(lcd_string,"Stevec: "); //pazi da ne overflowa (n>=32); sprintf vrne zadeve
    lcd_string[n]=' ';                      // v tej vrsti povozimo kar sprinf vrne
    lcd_driver();

    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0,0,TC_CMR_WAVE|TC_CMR_TCCLKS_TIMER_CLOCK3);
    //tc_enable_interrupt(TC0,0,TC_IER_CPCS);
    tc_start(TC0,0);
    //cadence elektronika


    // Komande za zunanje prekinitve:
    //NVIC nadzornik prekinitev,  nested vector interupt controller

    //zbrisat prvi klic funkcije ko se sistem vklopi in gre po definiciji iz 0 na 1
    pio_disable_interrupt(PIOC,PIO_PC23|PIO_PC26 |PIO_PC25 |PIO_PC24);
    NVIC_DisableIRQ(PIOC_IRQn);

    //briše IRQ flag na NVIC, izbriše iz čakalnice,  da ne dva hkrati probata pisat isti podatek
    NVIC_ClearPendingIRQ(PIOC_IRQn);

    pio_get_interrupt_status(PIOC); //briše IRQ flag na PIO, in še prebere status.        zastavca pravi ali je čas za zagnat interupt handler
    pio_configure_interrupt(PIOC,PIO_PC23|PIO_PC26 |PIO_PC25 |PIO_PC24,PIO_IT_FALL_EDGE); //povezati

     //   pio in  nvic se pogovarjata. en mora oddajat drugi sprejemat
    NVIC_EnableIRQ(PIOC_IRQn);
    pio_enable_interrupt(PIOC,PIO_PC23|PIO_PC26 |PIO_PC25 |PIO_PC24);




    //KOMANDE ZA TIMER IN PREKINITVE:
    NVIC_EnableIRQ(TC0_IRQn);
    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0,0,TC_CMR_WAVE|TC_CMR_TCCLKS_TIMER_CLOCK3|TC_CMR_WAVSEL_UP_RC);

    //calculating time, my brother
    ticks_interval = (uint32_t)(fticks/freq); //kolikokrat se mora povecat za ena da mine cel signal
    dcLow = ticks_interval/100*(100-dc);
    dcHigh = ticks_interval - dcLow;
    interval=dcHigh;

    tc_enable_interrupt(TC0,0,TC_IER_CPCS);
     /********************* Main loop     ***************************/


    tc_write_rc(TC0,0,interval);//Dc high na začetku
    tc_start(TC0,0);


     while(1)
    {

    uint8_t n=sprintf(lcd_string+16,"%10lu",stevec); //pazi da ne overflowa (n>=32); sprintf vrne zadeve
    lcd_string[n+16]=' ';                      // v tej vrsti povozimo kar sprinf vrne
    lcd_driver();



    }


    /* varnostna while zanka */
    while(1){}
}











//to se runna ko je karkoli pretisnjeno od c kar si enablal,  torej ali ena tipka ali druga
void PIOC_Handler(void){
        uint32_t stanje=pio_get_interrupt_status(PIOC);  //stanje pove za vse pine kateri so dobili interupt falling edge
        // MASKA NAM POVE ALI JE ZA TA PIN VKLOPLJEN IRQ
        //STATUS NAM POVE ALI JE BIL BUTTON PRITISNJEN
        uint32_t maske=pio_get_interrupt_mask(PIOC);  // maska ti špove kateri pini nas zanimajo, katere pine gledamo
        //btn1 je sam spremenljivka
        //če je na tipski  na istem mestu 1 kot na  maski npr 0000111  potem se enka bitwise ohrani
        bool btn1=stanje&PIO_PC26;   //ce je na mestu (pc26 npr 1<<26) stanje 1,   potem se ta enka bitwise ohrani
        bool btn4=stanje&PIO_PC23;   //ce je na mestu (pc23 npr 1<<23) stanje 1,   potem se ta enka bitwise ohrani
        if(btn1&&(stevec<1000000000))stevec++; //max num
        if(btn4&&(stevec>0))stevec--; //min num








        bool btn2=stanje&PIO_PC25;   //ce je na mestu (pc26 npr 1<<26) stanje 1,   potem se ta enka bitwise ohrani
        bool btn3=stanje&PIO_PC24;   //ce je na mestu (pc23 npr 1<<23) stanje 1,   potem se ta enka bitwise ohrani
        if  (btn2) blink1 = !blink1;
        if  (btn3)blink2 = !blink2;


        //delay_ms(10); // 1ms delay,  ni pomagalo
   }




void TC0_Handler(void){
    tc_get_status(TC0,0);//s tem  se umakne zahteva po prekinitvi, da ne pademo v ISR takoj ko se vrnemo v main
    //briše IRQ flag na PIO, in še prebere status.        zastavca pravi ali je čas za
if(blink1 | !stanje_LED){
    if (stanje_LED == 0)ioport_set_pin_level(LED2,0);
    if (stanje_LED == 0)tc_write_rc(TC0,0, dcLow);

    if (stanje_LED == 1)ioport_set_pin_level(LED2,1);
    if (stanje_LED == 1)tc_write_rc(TC0,0, dcHigh);

   stanje_LED = !stanje_LED;

   }

   if(blink2 | !stanje_LED2){
    if (stanje_LED2 == 0)ioport_set_pin_level(LED3,0);
    if (stanje_LED2 == 0)tc_write_rc(TC0,0, dcLow);

    if (stanje_LED2 == 1)ioport_set_pin_level(LED3,1);
    if (stanje_LED2 == 1)tc_write_rc(TC0,0, dcHigh);

   stanje_LED2 = !stanje_LED2;

   }

}


#ifdef __cplusplus
}
#endif
