
#ifndef TEST_BOARD_H_INCLUDED
#define TEST_BOARD_H_INCLUDED

#include <asf.h>

#define LED1 PIO_PC22_IDX
#define LED2 PIO_PC21_IDX
#define LED3 PIO_PC29_IDX
#define LED4 PIO_PD7_IDX


#define Tipka1 PIO_PA29_IDX
#define Tipka2 PIO_PC25_IDX
#define Tipka3 PIO_PC24_IDX
#define Tipka4 PIO_PC23_IDX


void init_buttons_leds(void);
uint32_t get_button_state(void);
uint32_t get_button_press(void);
void adc_setup(void);
uint32_t adc_read(void);
#endif // TEST_BOARD_H_INCLUDED
