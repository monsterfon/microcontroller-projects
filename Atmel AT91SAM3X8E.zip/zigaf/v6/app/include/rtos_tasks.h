#ifndef RTOD_TASKS_H_INCLUDED
#define RTOD_TASKS_H_INCLUDED

#include <rtos.h>
#include <lcd.h>

void blink_driver(void);
void blink1_driver(void);

void clock_driver(void);

void prepere_text_driver(void);

void buttons_driver(void);

#endif // RTOD_TASKS_H_INCLUDED
