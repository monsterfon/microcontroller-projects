#ifndef RTOS_H_INCLUDED
#define RTOS_H_INCLUDED

#include <asf.h>

//kazalec na funkcijo ki nic ne vraca in nic ne sprejema
typedef void (*ptr_function)(void);

//taski bodo strukture

//definiramo nov podatkovni tip
typedef struct{
    char name[20];
    uint32_t last_tick;
    //funkcijo klicemo tako da definiramo pointer na funkcijo
    ptr_function task_function;
}rtos_task_t;

uint8_t rtos_init(uint32_t slice_us);
void rtos_enable(void);
void rtos_disable(void);

#endif // RTOS_H_INCLUDED
