#include <test_board.h>
#include <asf.h>
#include <adc.h>

void init_buttons_leds(void){
    // inicializira vhodne in izhodne pine za testno ploščo
    ioport_init();

    ioport_set_pin_dir(LED1,IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED1,0);

    ioport_set_pin_dir(LED2,IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED2,0);


    ioport_set_pin_dir(LED3,IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED3,0);


    ioport_set_pin_dir(LED4,IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED4,0);

    //IOPORT_MODE_GLITCH_FILTER|IOPORT_MODE_DEBOUNCE|IOPORT_MODE_PULLUP
    ioport_set_pin_dir(Tipka1,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tipka1,IOPORT_MODE_PULLUP);

    ioport_set_pin_dir(Tipka2,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tipka2,IOPORT_MODE_PULLUP);

    ioport_set_pin_dir(Tipka3,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tipka3,IOPORT_MODE_PULLUP);

    ioport_set_pin_dir(Tipka4,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tipka4,IOPORT_MODE_PULLUP);

}

uint32_t get_button_state(void){
    /*
        vrne 32 bitov v out:
            bit 0 = 1 če je tipka 1 pritisnjena
            ....

            tipke so aktivna 0
    */
    uint32_t out = 0;
    // 1000 100 10 1
    //OR JE SEŠTEVALNIK
    //POVSOT SO NULE RAZEN TM KJER NISO
    //~ INVERTS ALL BITS
    //POVSOT SO ENKE RAZEN TAM KJER NISO
    out |= ( !ioport_get_pin_level(Tipka1) ) << 0 ;
    out |= ( !ioport_get_pin_level(Tipka2) ) << 1;
    out |= ( !ioport_get_pin_level(Tipka3) ) << 2;
    out |= ( !ioport_get_pin_level(Tipka4) ) << 3;
    //0000000
    return out;
}




uint32_t get_button_press(void){
    /*
    bit 0 = 1 če pritisk (fronta) na T1
    ...
    */
    uint32_t out = 0;
    uint32_t sprememba = 0;
    uint32_t trenutno_stanje = 0;
    static uint32_t old_state = 0;

    trenutno_stanje = get_button_state();
    //  (XOR 0000000 000001) AND  00001
    out = (trenutno_stanje^old_state) & ~old_state;

    old_state= trenutno_stanje;
    return out;
}


void adc_setup(void){
    sysclk_enable_peripheral_clock(ID_ADC);
    adc_init(ADC, 84000000, 6400000, ADC_STARTUP_TIME_4);
    adc_configure_timing(ADC, 0, ADC_SETTLING_TIME_3, 1);
    adc_set_resolution(ADC, ADC_12_BITS);
    adc_configure_trigger(ADC, ADC_TRIG_SW, 0);
    adc_enable_channel(ADC, ADC_CHANNEL_7);
}

uint32_t adc_read(void){
    uint16_t buffer=0;
    adc_start(ADC);
    // while(!(adc_get_status(ADC)&ADC_ISR_DRDY));
    while(!(adc_get_status(ADC)&(0x01<<7)));//če je bit 7  enak 1, ko je true gre vn iz loopa
    buffer = adc_get_channel_value(ADC, ADC_CHANNEL_7);
    return buffer;
}
