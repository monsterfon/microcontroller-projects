#include <asf.h>
#include <test_board.h>
#include <lcd.h>
#include <tc.h>
#include <rtos.h>


#ifdef __cplusplus
extern "C" {
#endif



int main (void)
{
    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();
    delay_init();
    ioport_init();
    init_buttons_leds();
    lcd_init();


    /*inicializacija operacijskega sistema*/
    //ce vrne 0 je vse ok
    if(rtos_init(20000) != 0){
        while(1); //error
    }
    rtos_enable();

    /*
    taski:  1)gonilnik ure
            2)priprava texta
            3)gonilnik za lcd
            4)gonilnik za tipke
    */



    /********************* Main loop     ***************************/

    while(1)
    {


    }
     /*********************Varnostna zanka da se program nikoli ne konca********/
    while(1){
    }
}

#ifdef __cplusplus
}
#endif
