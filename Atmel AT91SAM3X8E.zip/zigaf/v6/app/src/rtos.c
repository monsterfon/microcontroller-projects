#include <rtos.h>
//vstavimo globalno sprmeenljivko med fili
extern rtos_task_t *task_list[];

// Inicializacija real time os-a, konfiguracija SysTick za pravilno dolžino časovne rezine
// slice_us - dolzina enga slica
uint8_t rtos_init(uint32_t slice_us){

    /**
        vrne :  0 ok
                1 error
    **/

    // 2^24/(10500000/1000000) = 1597830
    uint32_t slice_us_max = 1597830;
    if(slice_us > slice_us_max){
        return 1;
    }

    // Highest priority
    NVIC_SetPriority(SysTick_IRQn, 0);

    // MCK/8 = 84000000/8 = 10500000
    // 10500000/1000000 je perioda
    uint32_t nticks = (10500000/1000000)*slice_us; //10500000 tickov na sekundo * (mikrosekunde * 1000000  da dovimo sekunde)

    SysTick -> CTRL = 0x00000002; //Omogoci system prekitnitve
    SysTick -> LOAD = nticks-1;

    return 0;
}

// Vklop rtos
void rtos_enable(void){
    //prvi bit na 1  vklopi SysTick Timer
    SysTick->CTRL = (SysTick -> CTRL)| (1<<0);

}

// Izklo rtos
void rtos_disable(void){
    //prvi bit na 0  izklopi SysTick Timer, morda smiselno relodat value na začetno vrednost -- init()
    SysTick -> CTRL = (SysTick -> CTRL) & ~(1<<0);

}

// Ko timer preseteje do 0, se aktivira za fukncija
void SysTick_Handler(void){
    /** RTOS razvrščevalnik **/

    static uint8_t idx = 0;
    static uint32_t tick = 0;

    tick++;

    task_list[idx] -> task_function();
    task_list[idx] -> last_tick = tick;
    idx++;

    if (task_list[idx] == 0){
        idx = 0;
    }

    if(SCB->ICSR & SCB_ICSR_PENDSTSET_Msk){ //ce je task daljsi od time slica se ob
        while(1);
    }
}
