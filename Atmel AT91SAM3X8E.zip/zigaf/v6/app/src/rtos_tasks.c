#include <rtos_tasks.h>
#include <test_board.h>
/** task blink **/

rtos_task_t task_blink = {
    .last_tick = 0,
    .name = "blink",
    .task_function = blink_driver  //spustis oklepaje in dobis naslov
};

void blink_driver(void){
  /** heartbeat **/
  ioport_toggle_pin_level(LED1);
}

/** task blink 1**/

rtos_task_t task_blink1 = {
    .last_tick = 0,
    .name = "blink1",
    .task_function = blink1_driver  //spustis oklepaje in dobis naslov
};

void blink1_driver(void){
  /** heartbeat **/
  ioport_toggle_pin_level(LED2);
}

/**  task clock**/
rtos_task_t task_clock = {
    .last_tick = 0,
    .name = "clock",
    .task_function = clock_driver  //spustis oklepaje in dobis naslov
};

uint32_t time = 0;
void clock_driver(void){
    time++;
    if(time > 864000){ //st sekund v enm dnevu
        time -= 864000;
    }
}

/** task pripravi text**/
rtos_task_t task_prepare_text = {
    .last_tick = 0,
    .name = "text",
    .task_function = prepere_text_driver  //spustis oklepaje in dobis naslov
};

void prepere_text_driver(void){
        uint32_t t = time/10;
        uint32_t s = (t)%60;
        uint32_t m = (t/60)%60;
        uint32_t h = (t/3600)%24;

        //h = time/3600
        //m = (time - h*3600)/60
        //s = (time - h*3600 - m*60);

        uint32_t n = sprintf(lcd_string, "%2d : %2d : %2d", h,m,s);
        lcd_string[n] = ' ';
}

/** task lcd **/
rtos_task_t task_lcd = {
    .last_tick = 0,
    .name = "lcd",
    .task_function = lcd_driver  //spustis oklepaje in dobis naslov
};

/** task buttons **/
rtos_task_t task_buttons = {
    .last_tick = 0,
    .name = "buttons",
    .task_function = buttons_driver  //spustis oklepaje in dobis naslov
};

void buttons_driver(void){
    int btn = get_button_press();
    int btn_state = get_button_state();
    if(btn & (1<<0)){         //T1
        time = time + 60*60*10;
    }
    else if(btn & (1<<1)){    //T2
        time = time + 60*10;
    }
    else if(btn_state & (1<<2)){   //T3
        time--;
    }
    else if(btn & (1<<3)){ //T4
        time = 0;
    }
}

/***************************************/
//lista vseh taskov -- ker nocemo graditi tabelo celotnih struktur, raje podajamo pointerje na strukture (&), elementi so torej kazalci (* na zacetku) , na koncu čuvaj
rtos_task_t *task_list[] = {&task_blink, &task_clock, &task_prepare_text, &task_lcd, &task_buttons, 0};


