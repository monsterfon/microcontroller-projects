#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <testBoard.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>

#ifdef __cplusplus
extern "C" {
#endif

/**/



#define D1_PORT PIOB
#define D1_PIN 27
#define D2_PORT PIOD
#define D2_PIN 8
#define D3_PORT PIOD
#define D3_PIN 7
#define D4_PORT PIOA
#define D4_PIN 28



uint32_t ticks_interval=0;
uint32_t fticks = 84000000/32; //TC0_CLK / lolko pocasnej od sistem clocka hocemo da je
//dc v % dc cycle
//f v hz
//število ugasnjenih ciklov
//število prižganih ciklov
uint32_t dc = 25, freq = 1, dcHigh=0, dcLow=0, rc_state=0;
uint32_t state=0;
int fronte=0;
uint32_t cas_prej=0;
uint32_t stanje_LED=0;
uint32_t f_max=20;
uint32_t interval =0;


int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;



    /********************* HW init     ***************************/





    delay_init();
    init_buttons_leds();
    lcd_init();

    uint8_t n=sprintf(lcd_string,"Vaja 4"); //pazi da ne overflowa (n>=32); sprintf vrne zadeve
    lcd_string[n]=' ';                      // v tej vrsti povozimo kar sprinf vrne
    lcd_driver();
    //cadence elektronika

    //KOMANDE ZA TIMER IN PREKINITVE:
    NVIC_EnableIRQ(TC0_IRQn);
    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0,0,TC_CMR_WAVE|TC_CMR_TCCLKS_TIMER_CLOCK3|TC_CMR_WAVSEL_UP_RC);
    tc_enable_interrupt(TC0,0,TC_IER_CPCS);


    //calculating time, my brother
    ticks_interval = (uint32_t)(fticks/freq); //kolikokrat se mora povecat za ena da mine cel signal
    dcLow = ticks_interval/100*(100-dc);
    dcHigh = ticks_interval - dcLow;
    interval=dcHigh;;

     /********************* Main loop     ***************************/

    tc_write_rc(TC0,0,interval);//Dc high na začetku
    tc_start(TC0,0);

    while(1)
    {
     //   continue;

    n=sprintf(lcd_string,"f=%lu Hz",freq);
    lcd_string[n]=' ';

    n=sprintf(lcd_string+16,"dc Cycle=%lu %%",dc);
    lcd_string[n+16]=' ';//next line write this
    lcd_driver();
    fronte=get_button_press();
    if((fronte&1)&&(freq<f_max))freq++;
    if((fronte&2)&&(freq>1))freq--;
    if((fronte&4)&&(dc<95))dc++;
    if((fronte&8)&&(dc>5))dc--;


    //calculating time, my brother
    ticks_interval = (uint32_t)(fticks/freq); //kolikokrat se mora povecat za ena da mine cel signal
    dcLow = ticks_interval/100*(100-dc);
    dcHigh = ticks_interval - dcLow;
    interval=dcHigh;;




    }





    /*varnost*/
    while(1){}
 }


void TC0_Handler(void){
    tc_get_status(TC0,0);//s tem  se umakne zahteva po prekinitvi, da ne pademo v ISR takoj ko se vrnemo v main


    if (stanje_LED == 0)ioport_set_pin_level(LED1,0);
    if (stanje_LED == 0)tc_write_rc(TC0,0, dcLow);

    if (stanje_LED == 1)ioport_set_pin_level(LED1,1);
    if (stanje_LED == 1)tc_write_rc(TC0,0, dcHigh);

   stanje_LED = !stanje_LED;

}
#ifdef __cplusplus
}
#endif
